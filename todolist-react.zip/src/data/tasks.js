export const tasks = [
    {
      id: 0,
      titulo: "mi primer tarea",
      descripcion: "esta es mi primera tarea",
    },
    {
      id: 1,
      titulo: "mi segunda tarea",
      descripcion: "ya no sé que escribir",
    },
    {
      id: 2,
      titulo: "tengo poca imaginacion al parecer",
      descripcion: "no sé que poner acá",
    },
    {
      id: 3,
      titulo: "ya es el ultimo ejemplo",
      descripcion: "despertaste y le diste vuelta a mi universo",
    },
];
